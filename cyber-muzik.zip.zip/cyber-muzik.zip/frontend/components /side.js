import Link from 'next/link';
import { HomeIcon, MagnifyingGlassIcon, BuildingLibraryIcon, PlusIcon } from '@heroicons/react/24/outline';

export default function Sidebar() {
  return (
    <div className="w-64 bg-black h-full flex flex-col p-4 border-r border-zinc-800">
      <h1 className="text-2xl font-bold text-purple-500 mb-8">CYBER-MUZIK</h1>
      <nav className="space-y-4">
        <Link href="/" className="flex items-center gap-4 text-zinc-400 hover:text-white transition">
          <HomeIcon className="w-6 h-6" /> Home
        </Link>
        <Link href="/search" className="flex items-center gap-4 text-zinc-400 hover:text-white transition">
          <MagnifyingGlassIcon className="w-6 h-6" /> Search
        </Link>
        <Link href="/library" className="flex items-center gap-4 text-zinc-400 hover:text-white transition">
          <BuildingLibraryIcon className="w-6 h-6" /> Your Library
        </Link>
      </nav>
      <div className="mt-10">
        <button className="flex items-center gap-2 text-zinc-400 hover:text-white transition">
          <div className="p-1 bg-zinc-800 rounded-sm"><PlusIcon className="w-4 h-4" /></div>
          Create Playlist
        </button>
      </div>
    </div>
  );
}
