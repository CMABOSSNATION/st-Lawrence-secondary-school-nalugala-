"use client";
import { usePlayer } from "@/context/PlayerContext";
import { PlayIcon } from "@heroicons/react/24/solid";

export default function TrackList({ tracks }) {
  const { playTrack, currentTrack } = usePlayer();

  return (
    <div className="w-full">
      {tracks.map((track, index) => (
        <div 
          key={track.id}
          onClick={() => playTrack(track)}
          className={`flex items-center justify-between p-3 rounded-md hover:bg-white/10 cursor-pointer group ${currentTrack?.id === track.id ? 'bg-white/5 text-purple-400' : ''}`}
        >
          <div className="flex items-center gap-4">
            <span className="text-zinc-500 w-4">{index + 1}</span>
            <div>
              <p className="font-medium">{track.title}</p>
              <p className="text-sm text-zinc-400">{track.artistName}</p>
            </div>
          </div>
          <PlayIcon className="w-6 h-6 opacity-0 group-hover:opacity-100 transition" />
        </div>
      ))}
    </div>
  );
}
