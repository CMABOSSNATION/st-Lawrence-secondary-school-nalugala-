"use client";
import { useState, useEffect } from "react";
import TrackList from "@/components/TrackList";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);

  useEffect(() => {
    if (query.length > 2) {
      // Replace with your actual backend URL
      fetch(`http://localhost:5000/api/tracks/search?q=${query}`)
        .then(res => res.json())
        .then(data => setResults(data));
    }
  }, [query]);

  return (
    <div>
      <input 
        type="text" 
        placeholder="What do you want to listen to?"
        className="w-full max-w-md p-3 rounded-full bg-zinc-800 border-none focus:ring-2 focus:ring-purple-500 text-white"
        onChange={(e) => setQuery(e.target.value)}
      />
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4">Results</h2>
        <TrackList tracks={results} />
      </div>
    </div>
  );
}
